package me.dio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SantanderDevWeek2025Application {

	public static void main(String[] args) {
		SpringApplication.run(SantanderDevWeek2025Application.class, args);
	}
}
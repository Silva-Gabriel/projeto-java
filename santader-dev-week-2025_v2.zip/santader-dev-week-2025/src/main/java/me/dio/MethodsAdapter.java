package me.dio;

import me.dio.model.User;
import me.dio.response.classes.PutUserResponse;

import java.util.*;

public class MethodsAdapter {
    public static PutUserResponse AtualizarDados(User userUpdate, List<User> users)
    {
        var encontrado = false;
        var oldUsers = new ArrayList<>(users);

        users.replaceAll(x -> x.getId().equals(userUpdate.getId()) ? userUpdate : x);

        if (!Objects.equals(users, oldUsers))
        {
            encontrado = true;
        }

        return new PutUserResponse(users, encontrado);
    }
}

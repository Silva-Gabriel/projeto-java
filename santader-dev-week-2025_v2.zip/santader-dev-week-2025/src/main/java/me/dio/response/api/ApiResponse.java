package me.dio.response.api;

public class ApiResponse {
    public Object data = null;
    public Integer statusCode = null;
    public ErrorResponse error = null;

    public ApiResponse() {
    }

    public ApiResponse(Object data, int statusCode) {
        this.data = data;
        this.statusCode = statusCode;
    }
}

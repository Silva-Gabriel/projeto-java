package me.dio.response.classes;

import me.dio.model.User;

import java.util.List;

public class PutUserResponse {
    private List<User> Users = null;
    private Boolean Updated = false;

    public PutUserResponse(List<User> users, Boolean updated) {
        Users = users;
        Updated = updated;
    }

    public PutUserResponse() {
    }

    public List<User> getUsers() {
        return Users;
    }

    public void setUsers(List<User> users) {
        Users = users;
    }

    public Boolean getUpdated() {
        return Updated;
    }

    public void setUpdated(Boolean updated) {
        Updated = updated;
    }
}

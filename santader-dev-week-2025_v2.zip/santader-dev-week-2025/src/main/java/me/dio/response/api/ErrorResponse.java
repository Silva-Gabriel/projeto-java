package me.dio.response.api;

public class ErrorResponse {
    public String errorMessage;
    public String details;

    public ErrorResponse(String errorMessage, String details) {
        this.errorMessage = errorMessage;
        this.details = details;
    }
}

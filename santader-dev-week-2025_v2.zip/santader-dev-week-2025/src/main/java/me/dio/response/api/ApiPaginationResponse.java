package me.dio.response.api;

public class ApiPaginationResponse {
}

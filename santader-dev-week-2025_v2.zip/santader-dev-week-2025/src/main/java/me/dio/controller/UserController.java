package me.dio.controller;

import io.swagger.v3.oas.annotations.Operation;
import me.dio.model.User;
import me.dio.response.api.ErrorResponse;
import me.dio.response.api.ApiResponse;
import me.dio.response.classes.PutUserResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

import static me.dio.MethodsAdapter.AtualizarDados;
import static org.springframework.http.HttpStatus.*;

@RestController
@RequestMapping("/v1/user")
public class UserController {

    // todo - injeção de dependência => @Autowired
    public List<User> users = new ArrayList<>(List.of(new User(1L, "Gabriel"), new User(2L, "Kauã"), new User(3L, "Jeferson")));

    @GetMapping
    @Operation(summary = "Listar Usuários")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Quando nenhum resultado é encontrado")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Quando retorna resultado")
    public ResponseEntity<ApiResponse> ListarUsuarios()
    {
        var response = new ApiResponse();
        if (users == null)
        {
            response.error = new ErrorResponse("Nenhum usuário encontrado", "Nenhum usuário foi encontrado na base, adicione usuários para poder consultá-los.");
            response.statusCode = 204;

            return new ResponseEntity<>(response, NO_CONTENT);
        }

        response.data = users;
        response.statusCode = 200;

        return new ResponseEntity<>(response, OK);
    }

    @PostMapping
    @Operation(summary = "Adicionar usuário")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201", description = "Usuário criado com sucesso")
    public ResponseEntity<ApiResponse> CriarUsuario(@RequestBody User user)
    {
        var response = new ApiResponse();

        if (users.stream().anyMatch(x -> x.getId().equals(user.getId())))
        {
            response.error = new ErrorResponse("Usuário já existente", "Consulte o usuário existente para prosseguir com a manutenção.");
            response.statusCode = 409;

            return new ResponseEntity<>(response ,CONFLICT);
        }

        users.add(user);

        response.data = users;
        response.statusCode = 201;

        return new ResponseEntity<>(response, CREATED);
    }

    @DeleteMapping("{id}")
    @Operation(summary = "Remover usuário")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Usuário removido com sucesso")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Usuário não encontrado")
    public ResponseEntity<ApiResponse> RemoverUsuario(@RequestParam Long id)
    {
        var response = new ApiResponse();
        var encontrado = false;
        for (var user : users) {
            if (user.getId().equals(id)) {
                users.remove(user);
                encontrado = true;

                break;
            }
        }

        if (!encontrado)
        {
            response.error = new ErrorResponse("Usuário não encontrado", "Usuário não foi encontrado, acesse a área de criação de usuário para adicioná-lo na base.");
            response.statusCode = 404;

            return new ResponseEntity<>(response, NOT_FOUND);
        }

        response.data = id;
        response.statusCode = 200;

        return new ResponseEntity<>(response, OK);
    }

    @PutMapping
    @Operation(summary = "Atualizar informações do usuário")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Usuário atualizado com sucesso")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "422", description = "Não foi possível atualizar o usuário")
    public ResponseEntity<ApiResponse> AtualizarUsuario(@RequestBody User userUpdate)
    {
        var response = new ApiResponse();
        var result = new PutUserResponse();
        for (var user : users)
        {
            if (user.getId().equals(userUpdate.getId()))
            {
                result = AtualizarDados(userUpdate, users);
                break;
            }
        }

        if (!result.getUpdated())
        {
            response.error = new ErrorResponse(String.format("Não foi possível atualizar o usuário de id: %d", userUpdate.getId()), "Cliente não existente ou problemas de conexão com a base.");
            response.statusCode = 422;

            return new ResponseEntity<>(response, UNPROCESSABLE_ENTITY);
        }

        response.data = users;
        response.statusCode = 200;

        return new ResponseEntity<>(response, OK);
    }
}
